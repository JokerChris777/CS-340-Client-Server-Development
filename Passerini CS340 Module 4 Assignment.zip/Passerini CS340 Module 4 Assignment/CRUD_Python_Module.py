# Example Python Code to Insert a Document 

from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to access the MongoDB databases and collections. 
        # This connection requires authentication against the 'admin' database.
        self.client = MongoClient('mongodb://%s:%s@localhost:27017/?authSource=admin' % (username, password))
        self.database = self.client['aac']
        self.collection = self.database['animals']

    def create(self, data):
        """ Method to insert a document into the specified MongoDB collection """
        if data is not None:
            try:
                # Insert the dictionary data into the collection
                self.collection.insert_one(data)
                return True
            except Exception as e:
                print(f"An error occurred during insertion: {e}")
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    def read(self, query=None):
        """ Method to query for documents from the specified MongoDB collection """
        try:
            # If no query is provided, default to an empty dictionary to return all documents
            if query is None:
                query = {}
                
            # Execute find query and store the cursor
            cursor = self.collection.find(query)
            
            # Convert the MongoDB cursor to a standard Python list
            result_list = list(cursor)
            return result_list
            
        except Exception as e:
            print(f"An error occurred during query: {e}")
            return []