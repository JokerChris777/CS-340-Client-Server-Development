from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for the Animal collection in the AAC MongoDB database """

    def __init__(self, username, password):
        """ Initializing the MongoClient to establish database connection with authentication """
        # Connection string targets localhost and authenticates against the admin database
        self.client = MongoClient('mongodb://%s:%s@localhost:27017/?authSource=admin' % (username, password))
        self.database = self.client['aac']
        self.collection = self.database['animals']

    def create(self, data):
        """ Method to insert a document into the specified MongoDB collection """
        if data is not None:
            try:
                self.collection.insert_one(data)
                return True
            except Exception as e:
                print(f"An error occurred during insertion: {e}")
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    def read(self, query=None):
        """ Method to query for documents from the specified MongoDB collection """
        try:
            if query is None:
                query = {}
            # Executes the find query and returns a Python list from the database cursor
            cursor = self.collection.find(query)
            return list(cursor)
        except Exception as e:
            print(f"An error occurred during query: {e}")
            return []

    def update(self, query, update_data):
        """ Method to query for and change document(s) in the collection """
        if query is not None and update_data is not None:
            try:
                # Uses update_many to safely modify all matching documents
                # Expects update_data to contain an operator like '$set'
                result = self.collection.update_many(query, update_data)
                # Returns the exact integer count of modified objects
                return result.modified_count
            except Exception as e:
                print(f"An error occurred during update: {e}")
                return 0
        else:
            raise Exception("Update failed: Query parameters or update data cannot be empty")

    def delete(self, query):
        """ Method to query for and remove document(s) from the collection """
        if query is not None:
            try:
                # Uses delete_many to securely clear out target query groups
                result = self.collection.delete_many(query)
                # Returns the exact integer count of removed objects
                return result.deleted_count
            except Exception as e:
                print(f"An error occurred during deletion: {e}")
                return 0
        else:
            raise Exception("Delete failed: Query parameter cannot be empty")